// main function
fun main() {
    val tenToOne = 10.downTo(1)
    if (12 !in tenToOne) {
        println("No value 12 in Range ")
    }
}