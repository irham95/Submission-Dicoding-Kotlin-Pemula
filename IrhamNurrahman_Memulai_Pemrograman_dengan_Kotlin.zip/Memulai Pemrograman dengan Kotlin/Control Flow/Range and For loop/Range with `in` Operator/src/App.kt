// main function
fun main() {
    val tenToOne = 10.downTo(1)
    if (9 in tenToOne) {
        println("Value 9 available")
    }
}